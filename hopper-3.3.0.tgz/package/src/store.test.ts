import { afterEach, beforeEach, describe, expect, test } from "bun:test";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { Result } from "./result.ts";
import {
  addItem,
  cancelItem,
  claimNextItem,
  completeItem,
  findItem,
  getStorePath,
  loadItems,
  reprioritizeItem,
  requeueItem,
  saveItems,
  setStoreDir,
} from "./store.ts";
import { claimOrFail, makeItem } from "./test-helpers.ts";

function unwrap<T>(result: Result<T>): T {
  if (!result.ok) throw new Error(result.error);
  return result.value;
}

describe("store", () => {
  let tempDir: string;

  beforeEach(async () => {
    tempDir = await mkdtemp(join(tmpdir(), "hopper-test-"));
    setStoreDir(tempDir);
  });

  afterEach(async () => {
    await rm(tempDir, { recursive: true });
  });

  test("loadItems returns empty array when no file exists", async () => {
    const items = await loadItems();
    expect(items).toEqual([]);
  });

  test("saveItems creates file and loadItems reads it back", async () => {
    const items = [makeItem({ title: "First" }), makeItem({ title: "Second" })];
    await saveItems(items);

    const loaded = await loadItems();
    expect(loaded).toHaveLength(2);
    expect(loaded[0]?.title).toBe("First");
    expect(loaded[1]?.title).toBe("Second");
  });

  test("saveItems creates directory if missing", async () => {
    const nestedDir = join(tempDir, "nested", "dir");
    setStoreDir(nestedDir);

    await saveItems([makeItem()]);
    const loaded = await loadItems();
    expect(loaded).toHaveLength(1);
  });

  test("addItem prepends to existing items", async () => {
    await saveItems([makeItem({ title: "Existing" })]);
    await addItem(makeItem({ title: "New" }));

    const loaded = await loadItems();
    expect(loaded).toHaveLength(2);
    expect(loaded[0]?.title).toBe("New");
    expect(loaded[1]?.title).toBe("Existing");
  });

  test("addItem works when no file exists yet", async () => {
    await addItem(makeItem({ title: "First ever" }));

    const loaded = await loadItems();
    expect(loaded).toHaveLength(1);
    expect(loaded[0]?.title).toBe("First ever");
  });

  test("getStorePath returns path inside store dir", () => {
    expect(getStorePath()).toBe(join(tempDir, "items.json"));
  });

  // Migration tests
  test("loadItems applies status queued to legacy items missing status", async () => {
    const legacy = [
      { id: "1", title: "Old", description: "desc", createdAt: "2025-01-01T00:00:00Z" },
    ];
    await Bun.write(getStorePath(), JSON.stringify(legacy));

    const loaded = await loadItems();
    expect(loaded[0]?.status).toBe("queued");
  });

  // claimNextItem tests
  test("claimNextItem claims oldest queued item (FIFO)", async () => {
    const older = makeItem({ title: "Older", createdAt: "2025-01-01T00:00:00Z" });
    const newer = makeItem({ title: "Newer", createdAt: "2025-06-01T00:00:00Z" });
    await saveItems([newer, older]);

    const claimed = await claimNextItem("test-agent");
    expect(claimed).not.toBeNull();
    expect(claimed?.title).toBe("Older");
    expect(claimed?.status).toBe("in_progress");
    expect(claimed?.claimedBy).toBe("test-agent");
    expect(claimed?.claimToken).toBeDefined();
    expect(claimed?.claimedAt).toBeDefined();
  });

  test("claimNextItem returns undefined when queue is empty", async () => {
    const result = await claimNextItem();
    expect(result).toBeUndefined();
  });

  test("claimNextItem skips in_progress items", async () => {
    const inProgress = makeItem({
      title: "In Progress",
      status: "in_progress",
      workingDir: "/repo/a",
      createdAt: "2025-01-01T00:00:00Z",
    });
    const queued = makeItem({
      title: "Queued",
      status: "queued",
      workingDir: "/repo/b",
      createdAt: "2025-06-01T00:00:00Z",
    });
    await saveItems([inProgress, queued]);

    const claimed = await claimNextItem();
    expect(claimed?.title).toBe("Queued");
  });

  test("claimNextItem populates all claim fields", async () => {
    await saveItems([makeItem()]);

    const claimed = await claimNextItem("my-agent");
    expect(claimed?.status).toBe("in_progress");
    expect(claimed?.claimedAt).toBeTruthy();
    expect(claimed?.claimedBy).toBe("my-agent");
    expect(claimed?.claimToken).toBeTruthy();
  });

  // completeItem tests
  test("completeItem completes with valid token", async () => {
    await saveItems([makeItem()]);
    const claimed = await claimOrFail("agent");

    const { completed } = unwrap(await completeItem(claimed.claimToken, "agent"));
    expect(completed.status).toBe("completed");
    expect(completed.completedAt).toBeDefined();
    expect(completed.completedBy).toBe("agent");
    expect(completed.claimToken).toBeUndefined();
  });

  test("completeItem returns error result on invalid token", async () => {
    await saveItems([makeItem()]);
    await claimNextItem();

    const result = await completeItem("bad-token");
    expect(result).toMatchObject({
      ok: false,
      error: expect.stringContaining("No in-progress item found"),
    });
  });

  test("completeItem stores result when provided", async () => {
    await saveItems([makeItem()]);
    const claimed = await claimOrFail("agent");

    const { completed } = unwrap(
      await completeItem(claimed.claimToken, "agent", "Fixed the login bug"),
    );
    expect(completed.result).toBe("Fixed the login bug");

    const items = await loadItems();
    expect(items[0]?.result).toBe("Fixed the login bug");
  });

  test("completeItem leaves result undefined when not provided", async () => {
    await saveItems([makeItem()]);
    const claimed = await claimOrFail("agent");
    const { completed } = unwrap(await completeItem(claimed.claimToken, "agent"));
    expect(completed.result).toBeUndefined();
  });

  test("completeItem clears claim token after completion", async () => {
    await saveItems([makeItem()]);
    const claimed = await claimOrFail();
    await completeItem(claimed.claimToken);

    const items = await loadItems();
    // The first item might be a recurred item, find the completed one
    const completedItem = items.find((i) => i.status === "completed");
    expect(completedItem?.claimToken).toBeUndefined();
  });

  test("completeItem sets timestamps", async () => {
    await saveItems([makeItem()]);
    const claimed = await claimOrFail();
    const { completed } = unwrap(await completeItem(claimed.claimToken));

    expect(completed.completedAt).toBeTruthy();
    expect(new Date(completed.completedAt as string).getTime()).toBeGreaterThan(0);
  });

  // requeueItem tests
  test("requeueItem resets to queued", async () => {
    const item = makeItem();
    await saveItems([item]);
    const claimed = await claimOrFail();
    const requeued = unwrap(await requeueItem(claimed.id, "needs more info"));

    expect(requeued.status).toBe("queued");
    expect(requeued.requeueReason).toBe("needs more info");
  });

  test("requeueItem preserves createdAt", async () => {
    const originalCreatedAt = "2025-01-01T00:00:00Z";
    const item = makeItem({ createdAt: originalCreatedAt });
    await saveItems([item]);
    await claimNextItem();
    const requeued = unwrap(await requeueItem(item.id, "reason"));

    expect(requeued.createdAt).toBe(originalCreatedAt);
  });

  test("requeueItem clears claim fields", async () => {
    await saveItems([makeItem()]);
    const claimed = await claimOrFail("agent");
    const requeued = unwrap(await requeueItem(claimed.id, "blocked"));

    expect(requeued.claimedAt).toBeUndefined();
    expect(requeued.claimedBy).toBeUndefined();
    expect(requeued.claimToken).toBeUndefined();
  });

  test("requeueItem returns error result for non-in_progress items", async () => {
    const item = makeItem({ status: "queued" });
    await saveItems([item]);

    const result = await requeueItem(item.id, "reason");
    expect(result).toMatchObject({ ok: false, error: expect.stringContaining("not in progress") });
  });

  test("requeueItem returns error result on no match", async () => {
    await saveItems([makeItem()]);
    const result = await requeueItem("nonexistent", "reason");
    expect(result).toMatchObject({ ok: false, error: expect.stringContaining("No item found") });
  });

  test("requeueItem returns error result on ambiguous prefix", async () => {
    const a = makeItem({
      id: "abcd0000-0000-0000-0000-000000000000",
      status: "in_progress",
      claimedAt: new Date().toISOString(),
    });
    const b = makeItem({
      id: "abcd1111-0000-0000-0000-000000000000",
      status: "in_progress",
      claimedAt: new Date().toISOString(),
    });
    await saveItems([a, b]);
    const result = await requeueItem("abcd", "reason");
    expect(result).toMatchObject({
      ok: false,
      error: expect.stringContaining("Ambiguous id prefix"),
    });
  });

  // cancelItem tests
  test("cancelItem cancels a queued item", async () => {
    const item = makeItem({ title: "To cancel" });
    await saveItems([item]);

    const { item: cancelled } = unwrap(await cancelItem(item.id));
    expect(cancelled.status).toBe("cancelled");
    expect(cancelled.cancelledAt).toBeDefined();
    expect(cancelled.title).toBe("To cancel");
  });

  test("cancelItem returns error result for in_progress items", async () => {
    const item = makeItem({ status: "in_progress", claimedAt: new Date().toISOString() });
    await saveItems([item]);

    const result = await cancelItem(item.id);
    expect(result).toMatchObject({
      ok: false,
      error: expect.stringContaining('Cannot cancel item — status is "in_progress"'),
    });
  });

  test("cancelItem returns error result for completed items", async () => {
    const item = makeItem({ status: "completed", completedAt: new Date().toISOString() });
    await saveItems([item]);

    const result = await cancelItem(item.id);
    expect(result).toMatchObject({
      ok: false,
      error: expect.stringContaining("Only queued, scheduled, or blocked items can be cancelled"),
    });
  });

  test("cancelItem supports prefix matching", async () => {
    const item = makeItem({ id: "abcd1234-0000-0000-0000-000000000000", title: "Cancel me" });
    await saveItems([item]);

    const { item: cancelled } = unwrap(await cancelItem("abcd1234"));
    expect(cancelled.title).toBe("Cancel me");
    expect(cancelled.status).toBe("cancelled");
  });

  test("cancelItem returns error result on no match", async () => {
    await saveItems([makeItem()]);
    const result = await cancelItem("nonexistent");
    expect(result).toMatchObject({ ok: false, error: expect.stringContaining("No item found") });
  });

  test("cancelItem returns error result on ambiguous prefix", async () => {
    const a = makeItem({ id: "abcd0000-0000-0000-0000-000000000000" });
    const b = makeItem({ id: "abcd1111-0000-0000-0000-000000000000" });
    await saveItems([a, b]);
    const result = await cancelItem("abcd");
    expect(result).toMatchObject({
      ok: false,
      error: expect.stringContaining("Ambiguous id prefix"),
    });
  });

  test("cancelItem persists changes", async () => {
    const item = makeItem();
    await saveItems([item]);
    await cancelItem(item.id);

    const items = await loadItems();
    expect(items[0]?.status).toBe("cancelled");
    expect(items[0]?.cancelledAt).toBeDefined();
  });

  // scheduled item tests
  test("claimNextItem skips scheduled items that are not yet due", async () => {
    const futureDate = new Date(Date.now() + 3_600_000).toISOString(); // 1 hour from now
    const scheduled = makeItem({
      title: "Scheduled future",
      status: "scheduled",
      scheduledAt: futureDate,
      createdAt: "2025-01-01T00:00:00Z",
    });
    await saveItems([scheduled]);

    const claimed = await claimNextItem();
    expect(claimed).toBeUndefined();
  });

  test("claimNextItem claims scheduled items that are due", async () => {
    const pastDate = new Date(Date.now() - 1000).toISOString(); // 1 second ago
    const scheduled = makeItem({
      title: "Scheduled past",
      status: "scheduled",
      scheduledAt: pastDate,
      createdAt: "2025-01-01T00:00:00Z",
    });
    await saveItems([scheduled]);

    const claimed = await claimNextItem();
    expect(claimed).not.toBeNull();
    expect(claimed?.title).toBe("Scheduled past");
    expect(claimed?.status).toBe("in_progress");
  });

  test("claimNextItem prefers queued over not-yet-due scheduled", async () => {
    const futureDate = new Date(Date.now() + 3_600_000).toISOString();
    const scheduled = makeItem({
      title: "Scheduled",
      status: "scheduled",
      scheduledAt: futureDate,
      createdAt: "2025-01-01T00:00:00Z",
    });
    const queued = makeItem({
      title: "Queued",
      status: "queued",
      createdAt: "2025-06-01T00:00:00Z",
    });
    await saveItems([scheduled, queued]);

    const claimed = await claimNextItem();
    expect(claimed?.title).toBe("Queued");
  });

  test("cancelItem cancels a scheduled item", async () => {
    const item = makeItem({
      title: "Scheduled cancel",
      status: "scheduled",
      scheduledAt: new Date(Date.now() + 3_600_000).toISOString(),
    });
    await saveItems([item]);

    const { item: cancelled } = unwrap(await cancelItem(item.id));
    expect(cancelled.status).toBe("cancelled");
    expect(cancelled.cancelledAt).toBeDefined();
  });

  // findItem tests
  test("findItem returns item by exact id", async () => {
    const item = makeItem({ title: "Target" });
    await saveItems([makeItem({ title: "Other" }), item]);

    const found = unwrap(await findItem(item.id));
    expect(found.title).toBe("Target");
  });

  test("findItem returns item by prefix", async () => {
    const item = makeItem({ id: "abcd1234-0000-0000-0000-000000000000", title: "Target" });
    await saveItems([item]);

    const found = unwrap(await findItem("abcd1234"));
    expect(found.title).toBe("Target");
  });

  test("findItem returns error result on no match", async () => {
    await saveItems([makeItem()]);

    const result = await findItem("nonexistent");
    expect(result).toMatchObject({ ok: false, error: expect.stringContaining("No item found") });
  });

  test("findItem returns error result on ambiguous prefix", async () => {
    const a = makeItem({ id: "abcd0000-0000-0000-0000-000000000000" });
    const b = makeItem({ id: "abcd1111-0000-0000-0000-000000000000" });
    await saveItems([a, b]);

    const result = await findItem("abcd");
    expect(result).toMatchObject({
      ok: false,
      error: expect.stringContaining("Ambiguous id prefix"),
    });
  });

  // workingDir tests
  test("workingDir is preserved through add/claim/complete cycle", async () => {
    const item = makeItem({ workingDir: "/tmp/my-project" });
    await addItem(item);

    const claimed = await claimOrFail("agent");
    expect(claimed.workingDir).toBe("/tmp/my-project");

    const { completed } = unwrap(await completeItem(claimed.claimToken, "agent", "done"));
    expect(completed.workingDir).toBe("/tmp/my-project");

    const items = await loadItems();
    const completedItem = items.find((i) => i.status === "completed");
    expect(completedItem?.workingDir).toBe("/tmp/my-project");
  });

  test("items without workingDir still work (backward compat)", async () => {
    const item = makeItem();
    expect(item.workingDir).toBeUndefined();

    await addItem(item);
    const claimed = await claimOrFail("agent");
    expect(claimed.workingDir).toBeUndefined();

    const { completed } = unwrap(await completeItem(claimed.claimToken, "agent"));
    expect(completed.workingDir).toBeUndefined();
  });

  // recurring item tests
  test("completeItem creates new scheduled item for recurring items", async () => {
    const item = makeItem({
      title: "Recurring task",
      recurrence: { interval: "4h", intervalMs: 4 * 3_600_000 },
    });
    await saveItems([item]);
    const claimed = await claimOrFail("agent");
    const { completed, recurred } = unwrap(await completeItem(claimed.claimToken, "agent", "done"));

    expect(completed.status).toBe("completed");
    expect(recurred).toBeDefined();
    expect(recurred?.status).toBe("scheduled");
    expect(recurred?.title).toBe("Recurring task");
    expect(recurred?.recurrence).toEqual({ interval: "4h", intervalMs: 4 * 3_600_000 });
    expect(recurred?.id).not.toBe(completed.id);

    const scheduledTime = new Date(recurred?.scheduledAt as string).getTime();
    const expectedTime = Date.now() + 4 * 3_600_000;
    expect(scheduledTime).toBeGreaterThanOrEqual(expectedTime - 200);
    expect(scheduledTime).toBeLessThanOrEqual(expectedTime + 200);

    const items = await loadItems();
    expect(items).toHaveLength(2);
    expect(items.filter((i) => i.status === "scheduled")).toHaveLength(1);
    expect(items.filter((i) => i.status === "completed")).toHaveLength(1);
  });

  test("completeItem does not re-queue when recurrence.until has passed", async () => {
    const item = makeItem({
      title: "Expiring task",
      recurrence: {
        interval: "1h",
        intervalMs: 3_600_000,
        until: new Date(Date.now() - 1000).toISOString(), // already expired
      },
    });
    await saveItems([item]);
    const claimed = await claimOrFail("agent");
    const { completed, recurred } = unwrap(await completeItem(claimed.claimToken, "agent"));

    expect(completed.status).toBe("completed");
    expect(recurred).toBeUndefined();

    const items = await loadItems();
    expect(items).toHaveLength(1);
    expect(items[0]?.status).toBe("completed");
  });

  test("completeItem preserves workingDir and branch on recurred item", async () => {
    const item = makeItem({
      title: "Dir task",
      workingDir: "/tmp/project",
      branch: "main",
      recurrence: { interval: "2h", intervalMs: 7_200_000 },
    });
    await saveItems([item]);
    const claimed = await claimOrFail("agent");
    const { recurred } = unwrap(await completeItem(claimed.claimToken, "agent"));

    expect(recurred?.workingDir).toBe("/tmp/project");
    expect(recurred?.branch).toBe("main");
  });

  // priority tests
  test("claimNextItem returns high-priority item before normal", async () => {
    const normal = makeItem({ title: "Normal", createdAt: "2025-01-01T00:00:00Z" });
    const high = makeItem({ title: "High", priority: "high", createdAt: "2025-06-01T00:00:00Z" });
    await saveItems([normal, high]);

    const claimed = await claimNextItem();
    expect(claimed?.title).toBe("High");
  });

  test("claimNextItem returns normal-priority item before low", async () => {
    const low = makeItem({ title: "Low", priority: "low", createdAt: "2025-01-01T00:00:00Z" });
    const normal = makeItem({ title: "Normal", createdAt: "2025-06-01T00:00:00Z" });
    await saveItems([low, normal]);

    const claimed = await claimNextItem();
    expect(claimed?.title).toBe("Normal");
  });

  test("claimNextItem returns older item first within same priority", async () => {
    const older = makeItem({ title: "Older", priority: "high", createdAt: "2025-01-01T00:00:00Z" });
    const newer = makeItem({ title: "Newer", priority: "high", createdAt: "2025-06-01T00:00:00Z" });
    await saveItems([newer, older]);

    const claimed = await claimNextItem();
    expect(claimed?.title).toBe("Older");
  });

  test("items without priority field treated as normal", async () => {
    const noPriority = makeItem({ title: "No priority", createdAt: "2025-01-01T00:00:00Z" });
    const high = makeItem({ title: "High", priority: "high", createdAt: "2025-06-01T00:00:00Z" });
    await saveItems([noPriority, high]);

    const claimed = await claimNextItem();
    expect(claimed?.title).toBe("High");
  });

  test("completeItem decrements remainingRuns on recurred item", async () => {
    const item = makeItem({
      title: "Limited recurring",
      recurrence: { interval: "1h", intervalMs: 3_600_000, remainingRuns: 2 },
    });
    await saveItems([item]);
    const claimed = await claimOrFail("agent");
    const { recurred } = unwrap(await completeItem(claimed.claimToken, "agent"));

    expect(recurred).toBeDefined();
    expect(recurred?.recurrence?.remainingRuns).toBe(1);
  });

  test("completeItem stops recurrence when remainingRuns reaches 0", async () => {
    const item = makeItem({
      title: "Last run",
      recurrence: { interval: "1h", intervalMs: 3_600_000, remainingRuns: 0 },
    });
    await saveItems([item]);
    const claimed = await claimOrFail("agent");
    const { completed, recurred } = unwrap(await completeItem(claimed.claimToken, "agent"));

    expect(completed.status).toBe("completed");
    expect(recurred).toBeUndefined();

    const items = await loadItems();
    expect(items).toHaveLength(1);
    expect(items[0]?.status).toBe("completed");
  });

  test("completeItem recurs normally when remainingRuns is not set", async () => {
    const item = makeItem({
      title: "Unlimited recurring",
      recurrence: { interval: "1h", intervalMs: 3_600_000 },
    });
    await saveItems([item]);
    const claimed = await claimOrFail("agent");
    const { recurred } = unwrap(await completeItem(claimed.claimToken, "agent"));

    expect(recurred).toBeDefined();
    expect(recurred?.recurrence?.remainingRuns).toBeUndefined();
  });

  test("completeItem preserves priority on recurred item", async () => {
    const item = makeItem({
      title: "Priority recurring",
      priority: "high",
      recurrence: { interval: "1h", intervalMs: 3_600_000 },
    });
    await saveItems([item]);
    const claimed = await claimOrFail("agent");
    const { recurred } = unwrap(await completeItem(claimed.claimToken, "agent"));

    expect(recurred?.priority).toBe("high");
  });

  // reprioritize tests
  test("reprioritizeItem changes priority on queued item", async () => {
    const item = makeItem({ title: "Repri" });
    await saveItems([item]);

    const { item: updated, oldPriority } = unwrap(await reprioritizeItem(item.id, "high"));
    expect(updated.priority).toBe("high");
    expect(oldPriority).toBe("normal");

    const items = await loadItems();
    expect(items[0]?.priority).toBe("high");
  });

  test("reprioritizeItem changes priority on scheduled item", async () => {
    const item = makeItem({
      title: "Scheduled repri",
      status: "scheduled",
      scheduledAt: new Date(Date.now() + 3_600_000).toISOString(),
    });
    await saveItems([item]);

    const { item: updated } = unwrap(await reprioritizeItem(item.id, "low"));
    expect(updated.priority).toBe("low");
  });

  test("reprioritizeItem returns error result for in-progress items", async () => {
    const item = makeItem({ status: "in_progress", claimedAt: new Date().toISOString() });
    await saveItems([item]);

    const result = await reprioritizeItem(item.id, "high");
    expect(result).toMatchObject({
      ok: false,
      error: expect.stringContaining("Cannot reprioritize item"),
    });
  });

  test("reprioritizeItem returns error result for completed items", async () => {
    const item = makeItem({ status: "completed", completedAt: new Date().toISOString() });
    await saveItems([item]);

    const result = await reprioritizeItem(item.id, "high");
    expect(result).toMatchObject({
      ok: false,
      error: expect.stringContaining("Cannot reprioritize item"),
    });
  });

  // dependency tests
  test("blocked item is not returned by claimNextItem", async () => {
    const dep = makeItem({ title: "Dep", createdAt: "2025-01-01T00:00:00Z" });
    const blocked = makeItem({
      title: "Blocked",
      status: "blocked",
      dependsOn: [dep.id],
      createdAt: "2025-01-02T00:00:00Z",
    });
    await saveItems([dep, blocked]);

    const claimed = await claimNextItem();
    expect(claimed?.title).toBe("Dep");
  });

  test("completing dependency unblocks dependent item to queued", async () => {
    const dep = makeItem({ title: "Dep" });
    const blocked = makeItem({
      title: "Blocked",
      status: "blocked",
      dependsOn: [dep.id],
    });
    await saveItems([dep, blocked]);

    const claimed = await claimOrFail();
    expect(claimed.title).toBe("Dep");
    await completeItem(claimed.claimToken, "agent");

    const items = await loadItems();
    const unblockedItem = items.find((i) => i.title === "Blocked");
    expect(unblockedItem?.status).toBe("queued");
  });

  test("completing dependency unblocks dependent with scheduledAt to scheduled", async () => {
    const dep = makeItem({ title: "Dep" });
    const blocked = makeItem({
      title: "Blocked",
      status: "blocked",
      dependsOn: [dep.id],
      scheduledAt: new Date(Date.now() + 3_600_000).toISOString(),
    });
    await saveItems([dep, blocked]);

    const claimed = await claimOrFail();
    await completeItem(claimed.claimToken, "agent");

    const items = await loadItems();
    const unblockedItem = items.find((i) => i.title === "Blocked");
    expect(unblockedItem?.status).toBe("scheduled");
  });

  test("multiple dependencies: all must complete before unblock", async () => {
    const dep1 = makeItem({ title: "Dep1" });
    const dep2 = makeItem({ title: "Dep2" });
    const blocked = makeItem({
      title: "Blocked",
      status: "blocked",
      dependsOn: [dep1.id, dep2.id],
    });
    await saveItems([dep1, dep2, blocked]);

    // Complete dep1
    const claimed1 = await claimOrFail();
    await completeItem(claimed1.claimToken, "agent");

    let items = await loadItems();
    let blockedItem = items.find((i) => i.title === "Blocked");
    expect(blockedItem?.status).toBe("blocked");

    // Complete dep2
    const claimed2 = await claimOrFail();
    expect(claimed2.title).toBe("Dep2");
    await completeItem(claimed2.claimToken, "agent");

    items = await loadItems();
    blockedItem = items.find((i) => i.title === "Blocked");
    expect(blockedItem?.status).toBe("queued");
  });

  test("partial completion: item stays blocked", async () => {
    const dep1 = makeItem({ title: "Dep1" });
    const dep2 = makeItem({ title: "Dep2" });
    const blocked = makeItem({
      title: "Blocked",
      status: "blocked",
      dependsOn: [dep1.id, dep2.id],
    });
    await saveItems([dep1, dep2, blocked]);

    const claimed = await claimOrFail();
    await completeItem(claimed.claimToken, "agent");

    const items = await loadItems();
    const blockedItem = items.find((i) => i.title === "Blocked");
    expect(blockedItem?.status).toBe("blocked");
  });

  test("cancelled dependency: blocked item stays blocked", async () => {
    const dep = makeItem({ title: "Dep" });
    const blocked = makeItem({
      title: "Blocked",
      status: "blocked",
      dependsOn: [dep.id],
    });
    await saveItems([dep, blocked]);

    await cancelItem(dep.id);

    const items = await loadItems();
    const blockedItem = items.find((i) => i.title === "Blocked");
    expect(blockedItem?.status).toBe("blocked");
  });

  test("cancelItem returns blocked dependent count", async () => {
    const dep = makeItem({ title: "Dep" });
    const blocked1 = makeItem({
      title: "Blocked1",
      status: "blocked",
      dependsOn: [dep.id],
    });
    const blocked2 = makeItem({
      title: "Blocked2",
      status: "blocked",
      dependsOn: [dep.id],
    });
    await saveItems([dep, blocked1, blocked2]);

    const { blockedDependentCount } = unwrap(await cancelItem(dep.id));
    expect(blockedDependentCount).toBe(2);
  });

  test("cancelItem allows cancelling blocked items", async () => {
    const dep = makeItem({ title: "Dep" });
    const blocked = makeItem({
      title: "Blocked",
      status: "blocked",
      dependsOn: [dep.id],
    });
    await saveItems([dep, blocked]);

    const { item: cancelled } = unwrap(await cancelItem(blocked.id));
    expect(cancelled.status).toBe("cancelled");
  });

  test("blocked item with no remaining queued deps stays blocked when unrelated item completes", async () => {
    const dep = makeItem({ title: "Dep" });
    const unrelated = makeItem({ title: "Unrelated" });
    const blocked = makeItem({
      title: "Blocked",
      status: "blocked",
      dependsOn: [dep.id],
    });
    await saveItems([dep, unrelated, blocked]);

    // Complete the unrelated item
    const claimed = await claimOrFail();
    // Could claim either dep or unrelated, let's be specific
    if (claimed.title === "Unrelated") {
      await completeItem(claimed.claimToken, "agent");
      const items = await loadItems();
      const blockedItem = items.find((i) => i.title === "Blocked");
      expect(blockedItem?.status).toBe("blocked");
    } else {
      // If dep was claimed first, complete it and verify unblock
      await completeItem(claimed.claimToken, "agent");
      const items = await loadItems();
      const blockedItem = items.find((i) => i.title === "Blocked");
      expect(blockedItem?.status).toBe("queued");
    }
  });

  test("claimNextItem returns undefined when only blocked items exist", async () => {
    const blocked = makeItem({
      title: "Blocked",
      status: "blocked",
      dependsOn: ["some-nonexistent-id"],
    });
    await saveItems([blocked]);

    const claimed = await claimNextItem();
    expect(claimed).toBeUndefined();
  });

  test("dependsOn field is preserved through save/load", async () => {
    const dep = makeItem({ title: "Dep" });
    const blocked = makeItem({
      title: "Blocked",
      status: "blocked",
      dependsOn: [dep.id],
    });
    await saveItems([dep, blocked]);

    const items = await loadItems();
    const blockedItem = items.find((i) => i.title === "Blocked");
    expect(blockedItem?.dependsOn).toEqual([dep.id]);
  });

  // task type + agent tests
  test("type and agent fields round-trip through save/load", async () => {
    const item = makeItem({
      title: "Typed",
      type: "engineering",
      agent: "typescript-bun-cli-craftsperson",
    });
    await saveItems([item]);

    const items = await loadItems();
    expect(items[0]?.type).toBe("engineering");
    expect(items[0]?.agent).toBe("typescript-bun-cli-craftsperson");
  });

  test("type and agent are preserved through claim and complete", async () => {
    const item = makeItem({
      title: "Investigate",
      type: "investigation",
      agent: "rust-craftsperson",
    });
    await addItem(item);

    const claimed = await claimOrFail("agent");
    expect(claimed.type).toBe("investigation");
    expect(claimed.agent).toBe("rust-craftsperson");

    const { completed } = unwrap(await completeItem(claimed.claimToken, "agent", "done"));
    expect(completed.type).toBe("investigation");
    expect(completed.agent).toBe("rust-craftsperson");
  });

  test("legacy items without type or agent load unchanged", async () => {
    const legacy = makeItem({ title: "Legacy" });
    await saveItems([legacy]);

    const items = await loadItems();
    expect(items[0]?.type).toBeUndefined();
    expect(items[0]?.agent).toBeUndefined();
  });
});

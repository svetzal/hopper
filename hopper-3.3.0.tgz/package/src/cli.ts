#!/usr/bin/env bun

import { fail, runCommand } from "./command-runner.ts";
import { addCommand } from "./commands/add.ts";
import { createAgentResolver } from "./commands/add-agent-resolver.ts";
import { auditCommand } from "./commands/audit.ts";
import { cancelCommand } from "./commands/cancel.ts";
import { claimCommand } from "./commands/claim.ts";
import { completeCommand } from "./commands/complete.ts";
import { integrateCommand } from "./commands/integrate.ts";
import { listCommand } from "./commands/list.ts";
import { presetCommand } from "./commands/preset.ts";
import { profilesCommand } from "./commands/profiles.ts";
import { reprioritizeCommand } from "./commands/reprioritize.ts";
import { requeueCommand } from "./commands/requeue.ts";
import { showCommand } from "./commands/show.ts";
import { tagCommand, untagCommand } from "./commands/tag.ts";
import { workerCommand } from "./commands/worker-loop.ts";
import { VERSION } from "./constants.ts";
import { createAgentsGateway } from "./gateways/agents-gateway.ts";
import { createAuditGateway } from "./gateways/audit-gateway.ts";
import { createGitGateway } from "./gateways/git-gateway.ts";
import { createLlmGateway } from "./gateways/llm-gateway.ts";
import { createProfilesGateway } from "./gateways/profiles-gateway.ts";
import { createRoutingRunner } from "./gateways/routing-runner.ts";
import { createTitleGenerator } from "./titler.ts";

export interface ParsedArgs {
  command: string;
  positional: string[];
  flags: Record<string, string | boolean>;
  arrayFlags: Record<string, string[]>;
}

const SHORT_FLAG_ALIASES: Record<string, string> = {
  p: "priority",
};

const FLAG_ALIASES: Record<string, string> = {
  "depends-on": "after-item",
};

const REPEATABLE_FLAGS = new Set(["after-item", "tag"]);

export function parseArgs(args: string[]): ParsedArgs {
  const flags: Record<string, string | boolean> = {};
  const arrayFlags: Record<string, string[]> = {};
  const positional: string[] = [];

  let i = 0;
  while (i < args.length) {
    const arg = args[i] as string;
    if (arg.startsWith("--")) {
      let key = arg.slice(2);
      key = FLAG_ALIASES[key] ?? key;
      const nextArg = args[i + 1];
      if (nextArg && !nextArg.startsWith("-")) {
        if (REPEATABLE_FLAGS.has(key)) {
          if (!arrayFlags[key]) arrayFlags[key] = [];
          (arrayFlags[key] as string[]).push(nextArg);
        }
        flags[key] = nextArg;
        i += 2;
      } else {
        flags[key] = true;
        i += 1;
      }
    } else if (arg.startsWith("-") && arg.length === 2) {
      const short = arg.slice(1);
      const key = SHORT_FLAG_ALIASES[short] ?? short;
      const nextArg = args[i + 1];
      if (nextArg && !nextArg.startsWith("-")) {
        flags[key] = nextArg;
        i += 2;
      } else {
        flags[key] = true;
        i += 1;
      }
    } else {
      positional.push(arg);
      i += 1;
    }
  }

  return { command: positional[0] ?? "", positional: positional.slice(1), flags, arrayFlags };
}

function printHelp(): void {
  console.log(`hopper v${VERSION} — personal work queue

Usage:
  hopper add <description> [--after <timespec>]              Add a work item (optionally scheduled)
  hopper add <description> [--priority high|normal|low]      Add with priority (-p alias)
  hopper add <description> [--dir <path> --branch <branch>]  Add with working directory
  hopper add <description> [--command <cmd>]                 Add a shell command item
  hopper add <description> [--tag <tag>]                      Add with tags (repeatable)
  hopper add <description> [--after-item <id>]               Add blocked on another item (repeatable)
  hopper add <description> [--type investigation|engineering|task]  Set the task type (default: task)
  hopper add <description> [--agent <name>]                  Pin a craftsperson/agent
  hopper add --preset <name> [--after --every]               Create item from preset
  hopper audit <id>                  Show audit summary for an item
  hopper audit <id> --tail <n>       Last N decoded session events
  hopper audit <id> --plan           Show the engineering plan
  hopper audit <id> --result         Show the final result
  hopper audit <id> --phase <name>   Restrict to one phase (engineering only)
  hopper show <id>                   Show full details of an item
  hopper list                        List queued + in-progress + scheduled items
  hopper list --all                  Include completed items
  hopper list --completed            Show only completed items
  hopper list --scheduled            Show only scheduled items
  hopper list --tag <tag>             Filter by tag (repeatable, OR logic)
  hopper list --priority <level>     Filter by priority
  hopper list --type <type>          Filter by task type (investigation|engineering|task)
  hopper claim [--agent <name>]      Claim next queued item (priority, then FIFO)
  hopper complete <token>            Complete a claimed item
  hopper complete <token> --result "…" Attach a result summary
  hopper cancel <id>                 Cancel a queued item
  hopper integrate <id>              Merge item's branch into main and clean up worktree
  hopper integrate <id> --dry-run    Show commands without executing them
  hopper integrate <id> --keep-worktree  Leave worktree and branch after merge
  hopper requeue <id> --reason "…"   Return an in-progress item to queue
  hopper reprioritize <id> <level>   Change priority of a queued/scheduled item
  hopper tag <id> <tag> [<tag>...]   Add tags to an existing item
  hopper untag <id> <tag> [<tag>...] Remove tags from an existing item
  hopper preset add <name> <desc> [--dir --branch --command]  Save a reusable template
  hopper preset list                                List saved presets
  hopper preset remove <name>                       Delete a preset
  hopper preset show <name>                         Show preset details
  hopper init                        Install Claude Code skill files (local repo)
  hopper init --global               Install skill files to ~/.claude/skills/
  hopper init --force                Overwrite even if installed skill is newer
  hopper worker                      Run the worker loop (runner-agnostic; each
                                     item dispatches per its profile)
  hopper worker --once               Process one item then exit
  hopper worker --agent <name>       Set agent name (default: worker)
  hopper worker --interval <sec>     Poll interval in seconds (default: 60)
  hopper worker --concurrency <n>    Run up to N items in parallel (default: 4)
  hopper profiles                    List installed profiles
  hopper profiles show <name>        Print a profile file's contents

Options:
  --after     Schedule item for later (e.g. 1h, 30m, tomorrow 9am)
  --every     Make recurring (e.g. 4h, 1d). Minimum 5 minutes
  --times <n> Limit recurrences to n runs (requires --every)
  --until     End date for recurrence (requires --every)
  --command   Shell command to run instead of Claude (add command)
  --dir       Working directory for the task (add command)
  --branch    Git branch for the task (add command, required with --dir unless --command is set)
  --type      Task type: investigation, engineering, task (add command)
  --agent     Agent for claim/complete/worker; or craftsperson override (add command)
  --profile   Profile name for the item (add command). Defaults to defaultProfile
              from ~/.hopper/config.json. See 'hopper profiles' for installed.
  --dry-run         Print commands without executing them (integrate)
  --keep-worktree   Skip worktree and branch cleanup after merge (integrate)
  --json      Output as JSON
  --help      Show this help
  --version   Show version`);
}

async function main(): Promise<void> {
  const args = Bun.argv.slice(2);
  const parsed = parseArgs(args);

  if (parsed.flags.version) {
    console.log(VERSION);
    return;
  }

  if (parsed.flags.help || !parsed.command) {
    printHelp();
    return;
  }

  switch (parsed.command) {
    case "add": {
      const apiKey = process.env.OPENAI_API_KEY ?? "";
      const llm = apiKey ? createLlmGateway(apiKey) : undefined;
      const titler = createTitleGenerator(llm);
      const profilesGateway = createProfilesGateway();
      const agentResolver = createAgentResolver(createAgentsGateway(), createRoutingRunner());
      await runCommand(
        (p) => addCommand(p, titler, profilesGateway, undefined, agentResolver),
        parsed,
      );
      break;
    }
    case "list":
      await runCommand(listCommand, parsed);
      break;
    case "claim":
      await runCommand(claimCommand, parsed);
      break;
    case "cancel":
      await runCommand(cancelCommand, parsed);
      break;
    case "complete":
      await runCommand(completeCommand, parsed);
      break;
    case "requeue":
      await runCommand(requeueCommand, parsed);
      break;
    case "reprioritize":
      await runCommand(reprioritizeCommand, parsed);
      break;
    case "integrate": {
      const git = createGitGateway();
      await runCommand((p) => integrateCommand(p, git), parsed);
      break;
    }
    case "audit": {
      const audit = createAuditGateway();
      await runCommand((p) => auditCommand(p, audit), parsed);
      break;
    }
    case "show": {
      const audit = createAuditGateway();
      await runCommand((p) => showCommand(p, audit), parsed);
      break;
    }
    case "tag":
      await runCommand(tagCommand, parsed);
      break;
    case "untag":
      await runCommand(untagCommand, parsed);
      break;
    case "preset":
      await runCommand(presetCommand, parsed);
      break;
    case "profiles": {
      const profiles = createProfilesGateway();
      await runCommand((p) => profilesCommand(p, profiles), parsed);
      break;
    }
    case "init": {
      const { initCommand } = await import("./commands/init.ts");
      await initCommand(
        parsed.flags.json === true,
        parsed.flags.global === true,
        parsed.flags.force === true,
      );
      break;
    }
    case "worker":
      await workerCommand(parsed);
      break;
    default:
      printHelp();
      fail(`Unknown command: ${parsed.command}`);
  }
}

main();

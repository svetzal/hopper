import { join } from "node:path";
import type { SessionOptions } from "./gateways/agent-runner.ts";
import type { Item } from "./store.ts";
import { buildInvestigationOptions, buildInvestigationPrompt } from "./task-type-workflow.ts";

// ---------------------------------------------------------------------------
// Work setup
// ---------------------------------------------------------------------------

export type WorkSetup =
  | { type: "worktree"; repoDir: string; branch: string; worktreePath: string }
  | { type: "existing-dir"; dir: string }
  | { type: "cwd" };

/**
 * Decide where Claude should do its work based on the item's metadata.
 *
 * - Investigation items never get a worktree — they're read-only and have no
 *   branch to merge. They run in `workingDir` if set, otherwise in cwd.
 * - Items with both `workingDir` and `branch` get an isolated git worktree.
 * - Items with only `workingDir` run directly in that directory.
 * - All other items run in the current working directory.
 */
export function resolveWorkSetup(item: Item, hopperHome: string): WorkSetup {
  if (item.type === "investigation") {
    if (item.workingDir) {
      return { type: "existing-dir", dir: item.workingDir };
    }
    return { type: "cwd" };
  }
  if (item.workingDir && item.branch) {
    return {
      type: "worktree",
      repoDir: item.workingDir,
      branch: item.branch,
      worktreePath: join(hopperHome, "worktrees", item.id),
    };
  }
  if (item.workingDir) {
    return { type: "existing-dir", dir: item.workingDir };
  }
  return { type: "cwd" };
}

// ---------------------------------------------------------------------------
// Prompt builders
// ---------------------------------------------------------------------------

/**
 * Build the prompt that instructs Claude to complete the task described by
 * the item.
 */
export function buildTaskPrompt(item: Item): string {
  return (
    `You have been assigned the following task:\n\n` +
    `Title: ${item.title}\n` +
    `Description: ${item.description}\n\n` +
    `## Instructions\n\n` +
    `1. Analyze the task and plan your approach before writing code.\n` +
    `2. Implement the changes described above.\n` +
    `3. Before finishing, validate your work:\n` +
    `   - Run the project's test suite and ensure all tests pass.\n` +
    `   - Run the project's linter/type checker and fix any errors.\n` +
    `   - If the task description specifies additional validation steps, run those too.\n` +
    `   - If any checks fail, fix the issues before declaring done.\n` +
    `4. Do NOT commit your changes — the caller will handle committing.\n` +
    `5. Provide a clear summary of what you did, including validation results.\n`
  );
}

/**
 * Build a conventional commit message from the item and Claude's summary.
 *
 * Format:
 *   <title>
 *
 *   <summary>
 */
export function buildCommitMessage(item: Item, claudeResult: string): string {
  const body = claudeResult.trim();
  if (body) {
    return `${item.title}\n\n${body}`;
  }
  return item.title;
}

// ---------------------------------------------------------------------------
// Post-Claude decisions
// ---------------------------------------------------------------------------

/**
 * Decide whether Hopper should commit changes on Claude's behalf.
 *
 * Committing only makes sense when the work ran inside a worktree (so git
 * status is scoped to that branch) and there are uncommitted changes.
 */
export function resolvePostClaudeAction(
  hasWorktree: boolean,
  isWorktreeDirty: boolean,
): { shouldCommit: boolean } {
  return { shouldCommit: hasWorktree && isWorktreeDirty };
}

/**
 * Decide whether to merge the work branch back to the target branch.
 *
 * Merging only happens when Claude exited cleanly, a work branch was created,
 * and the item carries both a repo directory and a target branch name.
 */
export function resolveMergeAction(
  claudeExitCode: number,
  workBranch: string | undefined,
  item: Item,
): { shouldMerge: boolean } {
  const shouldMerge = claudeExitCode === 0 && !!workBranch && !!item.workingDir && !!item.branch;
  return { shouldMerge };
}

// ---------------------------------------------------------------------------
// Completion decision
// ---------------------------------------------------------------------------

export type CompletionAction =
  | { action: "complete"; result: string }
  | { action: "failed"; result: string };

/**
 * Decide whether to mark the item complete or leave it for manual requeue,
 * and compose the final result text.
 */
export function resolveCompletionAction(
  claudeExitCode: number,
  claudeResult: string,
  mergeNote: string,
): CompletionAction {
  const result = claudeResult + mergeNote;
  return claudeExitCode === 0 ? { action: "complete", result } : { action: "failed", result };
}

/**
 * Sentinel string returned by `extractResult` when the Claude session emitted
 * no `result`-type JSONL line. We compare against it to distinguish a
 * startup/crash failure (no real work done) from a genuine partial result.
 */
const NO_RESULT_SENTINEL = "(see audit log for details)";

export type AutoRequeueDecision =
  | { shouldAutoRequeue: false }
  | { shouldAutoRequeue: true; reason: string };

/**
 * Decide whether a non-zero exit looks like a pre-work startup failure that
 * the worker should auto-requeue without human intervention.
 *
 * The signal we trust is `extractResult`'s output: when Claude produced any
 * real `result`-type JSONL line, the captured string is the final assistant
 * response; when it didn't, we get the sentinel. A non-zero exit WITH the
 * sentinel means Claude failed before producing any captured work — almost
 * always an argv / environment / startup problem, not a task-level error that
 * deserves human triage. These should auto-requeue so the queue heals.
 *
 * Items with a real captured result (even if exit was non-zero) stay wedged
 * at in_progress on purpose — the operator probably wants to read the result
 * and decide whether to requeue.
 */
export function resolveAutoRequeue(exitCode: number, extractedResult: string): AutoRequeueDecision {
  if (exitCode === 0) return { shouldAutoRequeue: false };
  const trimmed = extractedResult.trim();
  if (trimmed === NO_RESULT_SENTINEL || trimmed === "") {
    return {
      shouldAutoRequeue: true,
      reason: `auto-requeue: Claude exited ${exitCode} before producing any result (likely a startup failure)`,
    };
  }
  return { shouldAutoRequeue: false };
}

export type CompletionPlan =
  | { kind: "complete"; finalResult: string }
  | { kind: "auto-requeue"; finalResult: string; reason: string }
  | { kind: "manual-requeue"; finalResult: string };

/**
 * Compose the completion and auto-requeue decisions into a single resolved
 * plan so the imperative shell can execute without making any branching
 * decisions of its own.
 */
export function resolveCompletionPlan(
  exitCode: number,
  result: string,
  mergeNote: string,
): CompletionPlan {
  const { action, result: finalResult } = resolveCompletionAction(exitCode, result, mergeNote);
  if (action === "complete") {
    return { kind: "complete", finalResult };
  }
  const autoRequeue = resolveAutoRequeue(exitCode, result);
  if (autoRequeue.shouldAutoRequeue) {
    return { kind: "auto-requeue", finalResult, reason: autoRequeue.reason };
  }
  return { kind: "manual-requeue", finalResult };
}

// ---------------------------------------------------------------------------
// Worker config
// ---------------------------------------------------------------------------

export interface WorkerConfig {
  agentName: string;
  pollInterval: number;
  runOnce: boolean;
  concurrency: number;
  /** Override the 60 s shutdown drain timeout (useful in tests). */
  shutdownTimeoutMs?: number;
}

export function resolveWorkerConfig(flags: Record<string, string | boolean>): WorkerConfig {
  return {
    agentName: typeof flags.agent === "string" ? flags.agent : "worker",
    pollInterval: typeof flags.interval === "string" ? parseInt(flags.interval, 10) : 60,
    runOnce: flags.once === true,
    concurrency: typeof flags.concurrency === "string" ? parseInt(flags.concurrency, 10) : 4,
  };
}

// ---------------------------------------------------------------------------
// Loop action
// ---------------------------------------------------------------------------

export type LoopAction =
  | { type: "wait-for-slot" }
  | { type: "claim"; freeSlots: number; shouldLog: boolean }
  | { type: "continue" };

export function resolveLoopAction(
  activeCount: number,
  concurrency: number,
  running: boolean,
): LoopAction {
  if (!running) {
    return { type: "continue" };
  }
  if (activeCount >= concurrency) {
    return { type: "wait-for-slot" };
  }
  const freeSlots = concurrency - activeCount;
  const shouldLog = activeCount === 0;
  return { type: "claim", freeSlots, shouldLog };
}

export type PostClaimAction =
  | { type: "exit-no-work"; message: string }
  | { type: "sleep"; message: string }
  | { type: "wait-and-exit" }
  | { type: "continue" };

export function resolvePostClaimLoopAction(
  activeCount: number,
  claimedAny: boolean,
  runOnce: boolean,
  pollInterval: number,
): PostClaimAction {
  if (activeCount === 0 && !claimedAny) {
    if (runOnce) {
      return { type: "exit-no-work", message: "No work available." };
    }
    return { type: "sleep", message: `No work available. Waiting ${pollInterval}s...` };
  }
  if (runOnce) {
    return { type: "wait-and-exit" };
  }
  // Active tasks exist but nothing new was claimed. Sleep instead of
  // returning `continue` — otherwise the outer loop re-enters `claimNext`
  // every tick, which re-reads ~/.hopper/items.json in a tight CPU-bound
  // loop until something completes. The store state cannot change faster
  // than the configured poll interval anyway (schedules fire on the minute,
  // dependencies unblock via active-task completions which the sleep does
  // NOT block — tasks run on their own promise chains).
  if (!claimedAny) {
    return {
      type: "sleep",
      message: `No new work; ${activeCount} active task(s). Waiting ${pollInterval}s...`,
    };
  }
  return { type: "continue" };
}

// ---------------------------------------------------------------------------
// Shutdown action
// ---------------------------------------------------------------------------

export type ShutdownAction =
  | { type: "already-shutting-down" }
  | { type: "shutdown"; message: string };

export function resolveShutdownAction(
  alreadyShuttingDown: boolean,
  activeCount: number,
): ShutdownAction {
  if (alreadyShuttingDown) {
    return { type: "already-shutting-down" };
  }
  if (activeCount > 0) {
    return {
      type: "shutdown",
      message: `\nShutting down. Waiting for ${activeCount} active task(s) to finish...`,
    };
  }
  return { type: "shutdown", message: "\nShutting down." };
}

// ---------------------------------------------------------------------------
// Audit paths
// ---------------------------------------------------------------------------

export interface AuditPaths {
  auditDir: string;
  auditFile: string;
  resultFile: string;
}

/**
 * Compute the canonical audit file paths for a given item.
 *
 * All audit artefacts live under `<hopperHome>/audit/` so they survive
 * worktree teardown and can be inspected after the fact.
 */
export function resolveAuditPaths(itemId: string, hopperHome: string): AuditPaths {
  const auditDir = join(hopperHome, "audit");
  return {
    auditDir,
    auditFile: join(auditDir, `${itemId}-audit.jsonl`),
    resultFile: join(auditDir, `${itemId}-result.md`),
  };
}

// ---------------------------------------------------------------------------
// Engineering audit paths
// ---------------------------------------------------------------------------

export interface EngineeringAuditPaths {
  auditDir: string;
  planAuditFile: string;
  executeAuditFile: string;
  validateAuditFile: string;
  /**
   * Markdown file holding the extracted plan text. Persisted under
   * `~/.hopper/audit/` — NEVER inside the worktree — so it survives worktree
   * teardown and cannot leak into the committed diff.
   */
  planFile: string;
  /**
   * Final result markdown file, same name the legacy task flow uses. Written
   * after validate to give `hopper show` a single place to read from.
   */
  resultFile: string;
}

export function resolveEngineeringAuditPaths(
  itemId: string,
  hopperHome: string,
): EngineeringAuditPaths {
  const auditDir = join(hopperHome, "audit");
  return {
    auditDir,
    planAuditFile: join(auditDir, `${itemId}-plan.jsonl`),
    executeAuditFile: join(auditDir, `${itemId}-execute.jsonl`),
    validateAuditFile: join(auditDir, `${itemId}-validate.jsonl`),
    planFile: join(auditDir, `${itemId}-plan.md`),
    resultFile: join(auditDir, `${itemId}-result.md`),
  };
}

/**
 * Audit file name for a specific phase attempt.
 *
 * Attempt 1 keeps the existing naming (`<id>-execute.jsonl`) so first-time
 * callers and existing consumers read exactly what they did before. Attempts
 * ≥ 2 get a suffix (`<id>-execute-2.jsonl`, etc.) so each remediation pass
 * has its own inspectable audit log.
 */
export function resolveAttemptAuditPath(
  itemId: string,
  hopperHome: string,
  phase: "execute" | "validate",
  attempt: number,
): string {
  const suffix = attempt <= 1 ? "" : `-${attempt}`;
  return join(hopperHome, "audit", `${itemId}-${phase}${suffix}.jsonl`);
}

// ---------------------------------------------------------------------------
// Execution plan — dispatch decisions for executeWork
// ---------------------------------------------------------------------------

export type ExecutionPlan =
  | { type: "command"; command: string }
  | { type: "investigation"; prompt: string; options: SessionOptions }
  | { type: "task"; prompt: string; options: SessionOptions };

/**
 * Build the environment that prepends the worker PATH-shim directory so
 * denied commands are intercepted regardless of how Bash composes the call.
 */
export function buildInvestigationShimEnv(
  hopperHome: string,
  realPath: string,
): { HOPPER_REAL_PATH: string; PATH: string } {
  const shimDir = join(hopperHome, "worker-shims");
  return {
    HOPPER_REAL_PATH: realPath,
    PATH: `${shimDir}:${realPath}`,
  };
}

/**
 * Decide how to execute a work item: run a shell command, run an
 * investigation session (sandboxed, read-only), or run a standard task
 * session.
 *
 * The returned plan contains everything the shell needs except `profile`
 * (which is injected at dispatch time so the pure function stays testable).
 */
export function resolveExecutionPlan(
  item: Item,
  hopperHome: string,
  realPath: string,
): ExecutionPlan {
  if (item.command) {
    return { type: "command", command: item.command };
  }
  if (item.type === "investigation") {
    const prompt = buildInvestigationPrompt(item);
    const env = buildInvestigationShimEnv(hopperHome, realPath);
    return { type: "investigation", prompt, options: { ...buildInvestigationOptions(), env } };
  }
  return { type: "task", prompt: buildTaskPrompt(item), options: {} };
}

// ---------------------------------------------------------------------------
// Completion labels
// ---------------------------------------------------------------------------

/**
 * Resolve the display labels used in completion log messages based on whether
 * the item ran a shell command or an agent session.
 */
export function resolveCompletionLabels(item: { command?: string }): {
  outputLabel: string;
  sessionLabel: string;
} {
  const isCommand = Boolean(item.command);
  return {
    outputLabel: isCommand ? "Command" : "Claude",
    sessionLabel: isCommand ? "Command" : "Claude session",
  };
}
